/** Automatically generated file. DO NOT MODIFY */
package android.app.printerapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}